// 假设要服务端web目录为webapp，vue打后文件放在webapp/template/dist目录，参考配置如下

let isProd = process.env.NODE_ENV === 'production'; // 是否生产模式，npm run build为生产模式，npm run serve 开发模式
let vueFilePath = './template/dist';     // 项目中根据实际路径进行调整

module.exports = {
  lintOnSave: true,       // 移除js编译警告，默认值default，有警告时不能访问页面
  publicPath: isProd ? vueFilePath : '/',  // 打包时使用server工程中的目录位置，非打包使用默认配置
  filenameHashing: !isProd                         // 文件是否需要hash，ipu更新静态资源不会移除历史已有资源，所以生产打包可以考虑不hash,减少体积客户端静态资源体积
};