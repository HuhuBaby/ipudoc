/**
 * 提供业务的AppMobile插件
 */
//define(["require"], function (require) {
  var BizMobile = (function () {
    return {
      openNative: function (data, err) {
        execute("openNative", [data], err);
      }, invokeIPU: function (pageAction, pageParam, err) {
        execute("openIPUFromOtherApp", [pageAction, pageParam], err);
      }, openRN: function (pageAction, callback) {
        storageCallback("openRN", callback);
        execute("openRN", [pageAction]);
      }, setKeyDownFlag: function (keyName, flag, err) {
        execute("setKeyDownFlag", [keyName, flag]);
      }
    };
  })();

  var IpuMobile;

  function execute(action, args, error, success) {
    /*循环依赖,懒加载*/
    if (!IpuMobile) {
      IpuMobile = require("../../../ipu/frame/mobile/ipu-mobile").default;
    }
    return IpuMobile.execute(action, args, error, success)
  }

  function storageCallback(action, callback, isEscape, isBase64) {
    /*循环依赖,懒加载*/
    if (!IpuMobile) {
      IpuMobile = require("../../../ipu/frame/mobile/ipu-mobile").default;
    }
    IpuMobile.callback.storageCallback(action, callback, isEscape, isBase64)
  }

  export default BizMobile;
  //return BizMobile;
//});