/**
 * Created by guohh on 2020/5/26.
 * 框架需要暴露的模块
 */
import Common from "./biz/js/common/common";
import Mobile from "./ipu/frame/mobile/mobile";
import IpuMobile from "./ipu/frame/mobile/ipu-mobile";
import jcl from "./ipu/frame/base/jcl";

export {
  Common,         // 通用业务方法封装
  Mobile,         // 框架对象，适配浏览器与app环境
  IpuMobile,      // 插件对象
  jcl             // Zepto扩展，增加了jcl.DataMap和jcl.DataSet数据格式，部分插件参数为jcl.DataMap或jcl.DatasetList
}