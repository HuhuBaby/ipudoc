<template>
  <div class="hello">
    <button @click="ipuBack()">ipu返回</button>
    <br><br>
    <button @click="vueBack()">vue返回</button>
    <br><br><br><br>
    <button @click="shock()">振动</button>
    <br><br>
    <button @click="dataRequest()">服务端接口请求</button>
    <br><br>
    <button @click="dataRequestCommon()">通过Common调用服务端接口请求</button>
    <br><br>
    <button @click="openUrl()">打开远程ipu官网</button>
    <br><br>
    <router-link :to="{ name: 'Error', params: { userId: 123 }}">Error page</router-link>
    <br><br>
  </div>
</template>

<script>
  import {jcl, IpuMobile, Mobile, Common} from  "../ipuframe";

  export default {
    name: 'HelloWorld',
    props: {
      msg: String
    },
    methods: {
      shock(){
        IpuMobile.shock(2000);
      },
      dataRequest(){
        var param = new jcl.DataMap();
        param.put("data", "test");

        // 数据请求
        Mobile.dataRequest("SceneBean.dataRequestScene", param, function (resultData) {
          // 获取返回的数据
          if (typeof (resultData) == "string") {
            resultData = new jcl.DataMap(resultData);
          }
          alert(resultData);
        });
      },
      dataRequestCommon(){
        var param = new jcl.DataMap();
        param.put("data", "testCommon");
        Common.callSvc("SceneBean.dataRequestScene",param,function (resultData) {
          // 获取返回的数据
          if (typeof (resultData) == "string") {
            resultData = new jcl.DataMap(resultData);
          }
          alert(resultData);
        });
      },
      vueBack(){
        this.$router.back()
      },
      ipuBack(){
        IpuMobile.back();
      },
      openUrl(){
        IpuMobile.openUrl("http://www.aiipu.com")
      }
    }
  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
  h3 {
    margin: 40px 0 0;
  }

  ul {
    list-style-type: none;
    padding: 0;
  }

  li {
    display: inline-block;
    margin: 0 10px;
  }

  a {
    color: #42b983;
  }

  .hello {
    text-align: left;
  }
</style>
