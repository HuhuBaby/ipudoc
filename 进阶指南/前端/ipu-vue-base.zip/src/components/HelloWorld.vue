<template>
  <div class="hello">
    <router-link :to="{ name: 'PlugDemo', params: { userId: 123 }}">PlugDemo page</router-link> <br><br>
    <router-link :to="{ name: 'Error', params: { userId: 123 }}">Error page</router-link> <br><br>
    <router-link :to="{ path: '/plugdemo', params: { userId: 123 }}">NotFind page</router-link> <br><br>
  </div>
</template>

<script>
export default {
  name: 'HelloWorld',
  props: {
    msg: String
  },
  methods: {
    pageBack() {
      this.$router.back()
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style >
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
.hello{
  text-align: left;
}
</style>
