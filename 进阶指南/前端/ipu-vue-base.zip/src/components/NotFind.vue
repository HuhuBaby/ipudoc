<template>
  <div class="hello">

    <button @click="pageBack()">返回</button>
    <br><br><br><br>
    <div class="">404</div>
  </div>
</template>

<script>
  export default {
    methods: {
      pageBack(){
        this.$router.back()
      }
    }
  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
