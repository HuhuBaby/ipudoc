<template>
  <div class="hello">

    <button class="result-message" @click="pageBack">返回</button>
    <br><br><br><br>
    <div class="ipu-toolbar-title">错误页面</div>
    <router-link :to="{ path: '/plugdemo', params: { userId: 123 }}">NotFind page</router-link> <br><br>
  </div>
</template>
<script type="text/ecmascript-6">
  export default {
    props: {},
    data: function () {
      return {}
    },
    computed: {},
    methods: {
      pageBack(){
        this.$router.back()
      }
    }
  }
</script>