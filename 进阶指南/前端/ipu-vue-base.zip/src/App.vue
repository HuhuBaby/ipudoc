<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<script>
  import {jcl, IpuMobile, Mobile, Common} from "./ipuframe";

  export default {
    name: 'App',
    created() {
      let _this = this
      if (IpuMobile.isAndroid()) { // 若为APP环境Android环境运行
        IpuMobile.setKeyDownFlag("back", true);  // js负责处理手机物理键返回事件

        IpuMobile.setKeyListener("back", function () {
          // 此判断条件目前只适用于abstract模式，vue-router文档未有描述history描述，此属性非标准属性，不同vue-router版本可能有差异导致判断条件失效
          if (_this.$router.history.index) {  // 其它则调用路由后退
            _this.$router.back();
          } else {            // 退至起始页，则调用退出，
            IpuMobile.setKeyDownFlag("back", false);  // APP负责处理手机物理键返回事件
            IpuMobile.back();    // 若是返回别的页面，调用此方法
            //IpuMobile.close(true);    // 退出app调用此方法，有参数true，则会有确认框，否则没有确认框
          }
        });
      }

      if (this.$router.mode == 'abstract') {  // 路由为absract模式时，需要主动进行一次路由跳转
        this.$router.push({name: 'HelloWorld'});  // HelloWorld应调整为工程实际首页路由名称
      }
    }
  }
</script>

<style>
  #app {
    font-family: Avenir, Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    text-align: center;
    color: #2c3e50;
    margin-top: 60px;
  }
</style>
