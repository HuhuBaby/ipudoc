import  HelloWorld from '../components/HelloWorld.vue'
import  PlugDemo from '../components/PlugDemo.vue'
import  NotFind from '../components/NotFind.vue'
import  Error from '../components/Error.vue'

export default [
  {
    path: '/',
    name: 'HelloWorld',
    component: HelloWorld
  }, {
    path: '/error',
    name: 'Error',
    component: Error
  }, {
    path: '/plugdemo',
    name: 'PlugDemo',
    component: PlugDemo
  }, {
    path: '/*',
    name: 'NotFind',
    component: NotFind
  }
]
