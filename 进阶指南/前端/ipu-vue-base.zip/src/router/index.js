import Vue from 'vue'
import VueRouter from 'vue-router'
import routes from './routes'

// 注册路由插件
Vue.use(VueRouter)

console.log(process.env.VUE_APP_ROUTER_MODE);
var mode = process.env.VUE_APP_ROUTER_MODE || 'abstract'

const router = new VueRouter({
  mode: mode,   // 开发模式下设置为hash更方便，生产模式下需为abstract，ipuApp只支持此模式
  base: './',   // 默认值/，建议为此值
  routes
})


export default router
